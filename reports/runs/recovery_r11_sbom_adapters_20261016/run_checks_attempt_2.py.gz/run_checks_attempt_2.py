"""独立纯适配切片验证收据，无PG/秘密配置/生产接线或外部访问。"""

import importlib.metadata
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

RUN = Path(__file__).resolve().parent
OUTPUT = RUN / "attempt_2"
ROOT = RUN.parents[2]
BACKEND = ROOT / "backend"
SOURCE = "src/ai_intel/assets/sbom_parser.py"
NEW_TESTS = ["tests/unit/test_r11_sbom_parser.py",
             "tests/contract/test_r11_sbom_contracts.py",
             "tests/security/test_r11_sbom_boundary.py"]


def main():
    OUTPUT.mkdir(exist_ok=False)
    commands = []
    (OUTPUT / "runtime_versions.json").write_text(json.dumps({
        "python": sys.version, "executable": sys.executable,
        "packages": {name: importlib.metadata.version(name) for name in
                     ("packageurl-python", "pytest", "ruff", "mypy", "jsonschema", "packaging", "semver")},
    }, indent=2), encoding="utf-8", newline="\n")
    checks = [
        ("ruff_final", ["-m", "ruff", "check", SOURCE, *NEW_TESTS]),
        ("format_final", ["-m", "ruff", "format", "--check", SOURCE, *NEW_TESTS]),
        ("mypy_final", ["-m", "mypy", "src/ai_intel"]),
    ]
    for layer, test in zip(("unit", "contract", "security"), NEW_TESTS, strict=True):
        checks.append((layer + "_final", ["-m", "pytest", test, "--no-cov", "-q",
                                         "--junitxml=" + str(OUTPUT / (layer + "_final.xml"))]))
    regression = [
        "tests/unit/test_r11_manifest_parser.py",
        "tests/unit/test_r11_manifest_parser_identity_time.py",
        "tests/contract/test_r11_manifest_candidate.py",
        "tests/security/test_r11_manifest_parser_boundary.py",
        "tests/unit/test_t26_version_engine.py",
        "tests/contract/test_r11_version_ranges_contract.py",
        "tests/security/test_r11_version_ranges_security.py",
        "tests/unit/test_t06_access_scope_boundaries.py",
        "tests/unit/test_r11_inventory.py",
        "tests/contract/test_r11_inventory_contracts.py",
        "tests/security/test_r11_inventory_boundary.py",
    ]
    checks.append(("regression_final", ["-m", "pytest", *regression, "--no-cov", "-q",
                                       "--junitxml=" + str(OUTPUT / "regression_final.xml")]))
    for name, arguments in checks:
        started = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
        tick = time.monotonic()
        result = subprocess.run([sys.executable, *arguments], cwd=BACKEND,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        finished = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
        (OUTPUT / (name + ".log")).write_bytes(result.stdout)
        record = {"name": name, "argv": [sys.executable, *arguments], "cwd": str(BACKEND),
                  "started_at": started, "finished_at": finished,
                  "elapsed_seconds": round(time.monotonic() - tick, 6),
                  "exit_code": result.returncode, "log": name + ".log"}
        xml_path = OUTPUT / (name + ".xml")
        if xml_path.exists():
            suite = ET.fromstring(xml_path.read_bytes()).find("testsuite")
            record["junit"] = {key: suite.get(key) for key in
                               ("tests", "failures", "errors", "skipped", "time")}
        commands.append(record)
        (OUTPUT / "commands_final.json").write_text(json.dumps(commands, indent=2), encoding="utf-8",
                                                 newline="\n")
        print(json.dumps({"name": name, "exit_code": result.returncode,
                          "elapsed_seconds": record["elapsed_seconds"],
                          "junit": record.get("junit")}), flush=True)
    return int(any(record["exit_code"] for record in commands))


if __name__ == "__main__":
    raise SystemExit(main())
