"""保留原证据bytes，逐Git blob校验冻结源码；不读取秘密或修改业务状态。"""

import gzip
import hashlib
import importlib.metadata
import io
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
CODE = "658ffb19af3f50c3b8e157e4f270dece92589444"


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=ROOT)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    uv = "C:/Users/yinha/.local/bin/uv.exe"
    arguments = [
        uv,
        "pip",
        "install",
        "--python",
        sys.executable,
        "--index-url",
        "https://pypi.org/simple",
        "--no-deps",
        "packageurl-python==0.17.6",
    ]
    started = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
    tick = time.monotonic()
    result = subprocess.run(
        arguments,
        cwd=ROOT / "backend",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    (RUN / "dependency_install_verification.log").write_bytes(result.stdout)
    assert result.returncode == 0
    (RUN / "dependency_install_verification.json").write_text(
        json.dumps(
            {
                "argv": arguments,
                "cwd": str(ROOT / "backend"),
                "started_at": started,
                "finished_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(
                    timespec="seconds"
                ),
                "elapsed_seconds": round(time.monotonic() - tick, 6),
                "exit_code": result.returncode,
                "version": importlib.metadata.version("packageurl-python"),
                "log": "dependency_install_verification.log",
            },
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    wheel = gzip.decompress((RUN / "packageurl_python-0.17.6-py3-none-any.whl.gz").read_bytes())
    assert digest(wheel) == "31a85c2717bc41dd818f3c62908685ff9eebcb68588213745b14a6ee9e7df7c9"
    installed = importlib.metadata.distribution("packageurl-python")
    module_records = []
    with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
        for name in archive.namelist():
            if name.startswith("packageurl/") and name.endswith(".py"):
                expected = archive.read(name)
                actual = Path(installed.locate_file(name)).read_bytes()
                assert actual == expected
                module_records.append(
                    {"path": name, "raw_bytes": len(actual), "sha256": digest(actual)}
                )
    (RUN / "packageurl_installed_code_proof.json").write_text(
        json.dumps(module_records, indent=2), encoding="utf-8", newline="\n"
    )

    proofs = []
    paths = git("diff-tree", "--no-commit-id", "--name-only", "-r", CODE).decode().splitlines()
    for path in paths:
        blob = git("show", CODE + ":" + path)
        object_id = git("rev-parse", CODE + ":" + path).decode().strip()
        assert git("hash-object", path).decode().strip() == object_id
        proofs.append(
            {
                "path": path,
                "code_commit": CODE,
                "git_blob": object_id,
                "blob_bytes": len(blob),
                "blob_sha256": digest(blob),
                "working_git_filtered_object_matches": True,
            }
        )
    (RUN / "frozen_source_proof.json").write_text(
        json.dumps(proofs, indent=2), encoding="utf-8", newline="\n"
    )

    for path in sorted(RUN.rglob("*")):
        if path.is_file() and path.suffix != ".gz" and path.name != "artifact_manifest.json":
            path.with_name(path.name + ".gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    artifacts = []
    junit = []
    for path in sorted(RUN.rglob("*.gz")):
        compressed = path.read_bytes()
        raw = gzip.decompress(compressed)
        artifacts.append(
            {
                "path": path.relative_to(RUN).as_posix(),
                "gzip_bytes": len(compressed),
                "gzip_sha256": digest(compressed),
                "raw_bytes": len(raw),
                "raw_sha256": digest(raw),
            }
        )
        if path.name.endswith(".xml.gz"):
            suite = ET.fromstring(raw).find("testsuite")
            junit.append(
                {
                    "path": path.relative_to(RUN).as_posix(),
                    **{
                        key: suite.get(key)
                        for key in ("tests", "failures", "errors", "skipped", "time")
                    },
                }
            )
    manifest = {
        "task": "R11/T24 bounded pure SBOM adapter",
        "status": "awaiting_review",
        "base_commit": "e310f7735bd499c4d9fbcefe8a644e2309a16a62",
        "code_commit": CODE,
        "sealed_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds"),
        "raw_evidence_policy": (
            "gzip bytes are authoritative; untracked raw local originals retained"
        ),
        "artifacts": artifacts,
        "junit": junit,
        "code_proof": proofs,
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    (RUN / "artifact_manifest.json").write_bytes(manifest_bytes)
    print(
        json.dumps(
            {
                "artifacts": len(artifacts),
                "source_files": len(proofs),
                "installed_library_files": len(module_records),
                "manifest_sha256": digest(manifest_bytes),
            }
        )
    )


if __name__ == "__main__":
    main()
