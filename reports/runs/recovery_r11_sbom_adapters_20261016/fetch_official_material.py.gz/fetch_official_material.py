"""固定官方规范/schema材料下载；仅研究期执行，adapter无此IO或联网能力。"""

import gzip
import hashlib
import importlib.metadata
import json
import subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

RUN = Path(__file__).resolve().parent
SOURCES = {
    "cyclonedx-1.5.schema.json": "https://raw.githubusercontent.com/CycloneDX/specification/1.5/schema/bom-1.5.schema.json",
    "cyclonedx-1.6.schema.json": "https://raw.githubusercontent.com/CycloneDX/specification/1.6/schema/bom-1.6.schema.json",
    "cyclonedx-1.7.schema.json": "https://raw.githubusercontent.com/CycloneDX/specification/1.7/schema/bom-1.7.schema.json",
    "spdx-2.3.1.schema.json": "https://raw.githubusercontent.com/spdx/spdx-spec/v2.3.1/schemas/spdx-schema.json",
    "cyclonedx-LICENSE.txt": "https://raw.githubusercontent.com/CycloneDX/specification/1.7/LICENSE",
    "spdx-LICENSE.txt": "https://raw.githubusercontent.com/spdx/spdx-spec/v2.3.1/LICENSE",
    "packageurl-pypi-0.17.6.json": "https://pypi.org/pypi/packageurl-python/0.17.6/json",
}


def main():
    receipts = []
    for name, url in SOURCES.items():
        started = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
        raw = subprocess.check_output(
            [
                "wsl",
                "-d",
                "Ubuntu-22.04",
                "-u",
                "root",
                "--exec",
                "curl",
                "--fail",
                "--silent",
                "--show-error",
                "--max-time",
                "20",
                "--proto",
                "=https",
                url,
            ]
        )
        assert len(raw) <= 1048576
        status = 200
        (RUN / (name + ".gz")).write_bytes(gzip.compress(raw, mtime=0))
        receipts.append(
            {
                "path": name + ".gz",
                "url": url,
                "status": status,
                "started_at": started,
                "finished_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(
                    timespec="seconds"
                ),
                "raw_bytes": len(raw),
                "raw_sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
    distribution = importlib.metadata.distribution("packageurl-python")
    (RUN / "official_material_receipt.json").write_text(
        json.dumps(
            {
                "sources": receipts,
                "installed_package": {
                    "name": distribution.metadata["Name"],
                    "version": distribution.version,
                    "license": distribution.metadata["License"],
                },
            },
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {"official_sources": len(receipts), "installed_packageurl": distribution.version}
        )
    )


if __name__ == "__main__":
    main()
