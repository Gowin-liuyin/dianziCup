"""Independently verify frozen gzip, raw, Git blobs, schemas and wheel bytes."""

import gzip
import hashlib
import importlib.metadata
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
AUTHOR = ROOT / "reports/runs/recovery_r11_sbom_adapters_20261016"
MATERIAL_SHA = "f6acedcd2b004671c317f55dd058f46e5e517de9"
CODE_SHA = "658ffb19af3f50c3b8e157e4f270dece92589444"
EXTRACT = RUN / "frozen_raw"
EXTRACT.mkdir(exist_ok=True)


def digest(content):
    return hashlib.sha256(content).hexdigest()


def git_blob(path, commit=MATERIAL_SHA):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=ROOT)


manifest_path = "reports/runs/recovery_r11_sbom_adapters_20261016/artifact_manifest.json"
manifest_bytes = git_blob(manifest_path)
manifest = json.loads(manifest_bytes)
records = []
for artifact in manifest["artifacts"]:
    relative = artifact["path"]
    working_gzip = (AUTHOR / relative).read_bytes()
    blob_gzip = git_blob("reports/runs/recovery_r11_sbom_adapters_20261016/" + relative)
    raw = gzip.decompress(blob_gzip)
    target = EXTRACT / relative.removesuffix(".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    matches = (
        working_gzip == blob_gzip
        and len(blob_gzip) == artifact["gzip_bytes"]
        and digest(blob_gzip) == artifact["gzip_sha256"]
        and len(raw) == artifact["raw_bytes"]
        and digest(raw) == artifact["raw_sha256"]
    )
    records.append({"path": relative, "matched": matches, "raw_sha256": digest(raw), "gzip_sha256": digest(blob_gzip)})
    assert matches, relative
code_records = []
for proof in manifest["code_proof"]:
    path = proof["path"]
    code = git_blob(path, CODE_SHA)
    material_code = git_blob(path)
    filtered = subprocess.check_output(["git", "hash-object", "--path=" + path, path], cwd=ROOT, text=True).strip()
    blob_id = subprocess.check_output(["git", "rev-parse", f"{CODE_SHA}:{path}"], cwd=ROOT, text=True).strip()
    matches = code == material_code and len(code) == proof["blob_bytes"] and digest(code) == proof["blob_sha256"] and blob_id == filtered == proof["git_blob"]
    assert matches, path
    code_records.append({"path": path, "matched": matches, "blob_bytes": len(code), "blob_sha256": digest(code), "git_blob": blob_id, "git_filtered_working_matches": filtered == blob_id, "git_has_crlf": b"\r\n" in code})
schemas = []
for name in ["cyclonedx-1.5", "cyclonedx-1.6", "cyclonedx-1.7", "spdx-2.3.1"]:
    schema_bytes = (EXTRACT / (name + ".schema.json")).read_bytes()
    schema = json.loads(schema_bytes)
    schemas.append({"name": name, "id": schema.get("$id", schema.get("id")), "dialect": schema.get("$schema"), "bytes": len(schema_bytes), "sha256": digest(schema_bytes)})
junit = []
for expected in manifest["junit"]:
    actual = ET.fromstring((EXTRACT / expected["path"].removesuffix(".gz")).read_bytes())
    suite = actual.find("testsuite") if actual.tag == "testsuites" else actual
    assert suite is not None
    for key in ["tests", "failures", "errors", "skipped", "time"]:
        assert suite.attrib[key] == expected[key], (expected["path"], key)
    junit.append({"path": expected["path"], **suite.attrib})
wheel_path = EXTRACT / "packageurl_python-0.17.6-py3-none-any.whl"
wheel_bytes = wheel_path.read_bytes()
assert digest(wheel_bytes) == "31a85c2717bc41dd818f3c62908685ff9eebcb68588213745b14a6ee9e7df7c9"
import packageurl
installed_root = Path(packageurl.__file__).parent.parent
installed = []
with zipfile.ZipFile(wheel_path) as wheel:
    for member in wheel.namelist():
        if member.startswith("packageurl/") and member.endswith(".py"):
            expected = wheel.read(member)
            actual = (installed_root / member).read_bytes()
            assert expected == actual, member
            installed.append({"path": member, "sha256": digest(actual), "matches_wheel": True})
receipt = {
    "verified_at": datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds"),
    "material_commit": MATERIAL_SHA,
    "code_commit": CODE_SHA,
    "manifest_git_bytes": len(manifest_bytes),
    "manifest_git_sha256": digest(manifest_bytes),
    "manifest_git_has_crlf": b"\r\n" in manifest_bytes,
    "manifest_working_bytes_sha256": digest((AUTHOR / "artifact_manifest.json").read_bytes()),
    "gzip_artifact_count": len(records),
    "all_gzip_and_raw_match": all(item["matched"] for item in records),
    "artifacts": records,
    "code_proof": code_records,
    "schemas": schemas,
    "author_junit": junit,
    "wheel_sha256": digest(wheel_bytes),
    "installed_packageurl_version": importlib.metadata.version("packageurl-python"),
    "installed_packageurl_code": installed,
    "python": sys.version,
    "runtime_versions": {name: importlib.metadata.version(name) for name in ["pytest", "ruff", "mypy", "jsonschema", "packageurl-python", "packaging", "semver"]},
    "review_commit": None,
}
(RUN / "frozen_material_verification.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({key: value for key, value in receipt.items() if key not in ["artifacts", "author_junit", "installed_packageurl_code"]}, ensure_ascii=False, indent=2))
