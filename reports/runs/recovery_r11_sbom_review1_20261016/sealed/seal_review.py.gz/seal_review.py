"""Freeze independent report and run bytes and verify every gzip round trip."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
REPORT = ROOT / "reports/reviews/recovery/G-D-R11-sbom-review-1.md"
SEALED = RUN / "sealed"
EXCLUDED = {"artifact_manifest.json", "review_seal_receipt.json", "seal.log", "seal.command.json"}
artifacts = []
sources = sorted(path for path in RUN.rglob("*") if path.is_file() and "sealed" not in path.relative_to(RUN).parts and "__pycache__" not in path.relative_to(RUN).parts and path.relative_to(RUN).as_posix() not in EXCLUDED)
for path in sources:
    raw = path.read_bytes()
    relative = path.relative_to(RUN).as_posix()
    packed = gzip.compress(raw, mtime=0)
    destination = SEALED / (relative + ".gz")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(packed)
    assert gzip.decompress(destination.read_bytes()) == raw
    artifacts.append({"raw_path": relative, "raw_bytes": len(raw), "raw_sha256": hashlib.sha256(raw).hexdigest(), "gzip_path": destination.relative_to(RUN).as_posix(), "gzip_bytes": len(packed), "gzip_sha256": hashlib.sha256(packed).hexdigest()})
report_raw = REPORT.read_bytes()
report_relative = REPORT.relative_to(ROOT).as_posix()
report_gzip = gzip.compress(report_raw, mtime=0)
(RUN / "report_frozen.md.gz").write_bytes(report_gzip)
filtered_id = subprocess.check_output(["git", "hash-object", "--path=" + report_relative, report_relative], cwd=ROOT, text=True).strip()
expected_id = hashlib.sha1(b"blob " + str(len(report_raw)).encode() + b"\0" + report_raw).hexdigest()
assert filtered_id == expected_id, "Report raw LF differs from Git filter"
report_proof = {"path": report_relative, "raw_bytes": len(report_raw), "raw_sha256": hashlib.sha256(report_raw).hexdigest(), "raw_contains_crlf": b"\r\n" in report_raw, "git_filtered_blob_id": filtered_id, "git_filtered_matches_raw_lf": True, "gzip_path": "report_frozen.md.gz", "gzip_bytes": len(report_gzip), "gzip_sha256": hashlib.sha256(report_gzip).hexdigest(), "review_commit": None}
manifest = {"sealed_at": datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds"), "review_commit": None, "code_commit": "658ffb19af3f50c3b8e157e4f270dece92589444", "material_commit": "f6acedcd2b004671c317f55dd058f46e5e517de9", "dependency_commit": "48b56033cf5daf3ce8cfaa710c0acbda7cc2356e", "combined_review_head": "bea469e5140a25877b076dee770db04fd944e2c7", "artifact_count": len(artifacts), "report": report_proof, "artifacts": artifacts, "exclusions": sorted(EXCLUDED), "exclusion_reason": "Terminal seal receipt and manifest have no recursive self-hash; seal controller logs are created after seal. Python runtime caches are not evidence."}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
(RUN / "artifact_manifest.json").write_bytes(manifest_bytes)
manifest_gzip = gzip.compress(manifest_bytes, mtime=0)
(RUN / "artifact_manifest.json.gz").write_bytes(manifest_gzip)
for artifact in artifacts:
    packed = (RUN / artifact["gzip_path"]).read_bytes()
    raw = gzip.decompress(packed)
    assert len(raw) == artifact["raw_bytes"] and hashlib.sha256(raw).hexdigest() == artifact["raw_sha256"]
    assert len(packed) == artifact["gzip_bytes"] and hashlib.sha256(packed).hexdigest() == artifact["gzip_sha256"]
assert gzip.decompress((RUN / "report_frozen.md.gz").read_bytes()) == REPORT.read_bytes()
assert gzip.decompress((RUN / "artifact_manifest.json.gz").read_bytes()) == manifest_bytes
receipt = {"verified_at": datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds"), "review_commit": None, "all_raw_and_gzip_verified": True, "artifact_count": len(artifacts), "manifest_raw_bytes": len(manifest_bytes), "manifest_raw_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "manifest_gzip_sha256": hashlib.sha256(manifest_gzip).hexdigest(), "report": report_proof}
(RUN / "review_seal_receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt, ensure_ascii=False, indent=2))
