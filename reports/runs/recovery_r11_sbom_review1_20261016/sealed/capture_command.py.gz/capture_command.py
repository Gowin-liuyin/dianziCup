"""Capture only explicit review commands with immutable output and real times."""

import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent
SHANGHAI = timezone(timedelta(hours=8), "Asia/Shanghai")
name, working_directory, *arguments = sys.argv[1:]
log_path = RUN / f"{name}.log"
receipt_path = RUN / f"{name}.command.json"
if receipt_path.exists():
    raise SystemExit(f"Capture already exists: {receipt_path}")
started_at = datetime.now(SHANGHAI).isoformat(timespec="seconds")
with log_path.open("wb") as output:
    result = subprocess.run(arguments, cwd=working_directory, stdout=output, stderr=subprocess.STDOUT, check=False)
receipt = {
    "cwd": working_directory,
    "argv": arguments,
    "started_at": started_at,
    "finished_at": datetime.now(SHANGHAI).isoformat(timespec="seconds"),
    "exit_code": result.returncode,
    "log": log_path.relative_to(RUN).as_posix(),
}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt, ensure_ascii=False))
print(log_path.read_text(encoding="utf-8", errors="replace"))
raise SystemExit(result.returncode)
