"""Measure isolated Windows adapter processes without changing parser budgets."""

import ctypes
import gzip
import hashlib
import json
import subprocess
import sys
import time
from ctypes import wintypes
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent


class MemoryCounters(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t), ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t), ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


def one(case):
    from ai_intel.assets.sbom_parser import SbomValidationError, parse_sbom
    from ai_intel.domain.access import AccessScope, Role

    if case == "dense_10000":
        raw = (RUN / "frozen_raw/synthetic-dense-10000.json").read_bytes()
    else:
        document = {"bomFormat": "CycloneDX", "specVersion": "1.7", "version": 1, "components": []}
        if case == "minimal_10000":
            document["components"] = [{"type": "library", "name": f"package-{index}"} for index in range(10000)]
        elif case == "two_field_10000":
            document["components"] = [{"type": "library", "name": f"p{index}", "version": "1"} for index in range(10000)]
        elif case == "exact_200000_nodes":
            document["opaque"] = [0] * 199989
        elif case == "over_200000_nodes":
            document["opaque"] = [0] * 199990
        else:
            raise ValueError(case)
        raw = json.dumps(document, separators=(",", ":")).encode()
    (RUN / ("resource-" + case + ".json.gz")).write_bytes(gzip.compress(raw, mtime=0))
    scope = AccessScope.for_authenticated_user("resource-review", "review-tenant", Role.ANALYST)
    now = datetime.now(UTC)
    started = time.perf_counter()
    try:
        result = parse_sbom(raw, sbom_format="cyclonedx_json", scope=scope, authorized_asset_tenant_id="review-tenant", asset_id="fa0d8b75-5c2d-432d-a833-c6bfcf2f8583", snapshot_number=1, source_version="independent-synthetic-resource", observed_at=now, recorded_at=now)
        status = {"status": "candidate", "components": len(result.manifest.snapshot.components)}
    except SbomValidationError as error:
        status = {"status": "typed_error", "code": error.code, "locator": error.locator}
    elapsed = time.perf_counter() - started
    counters = MemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    process_api = ctypes.WinDLL("kernel32", use_last_error=True)
    process_api.GetCurrentProcess.restype = wintypes.HANDLE
    memory_api = ctypes.WinDLL("psapi", use_last_error=True)
    memory_api.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD]
    if not memory_api.GetProcessMemoryInfo(process_api.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    print(json.dumps({"case": case, "raw_bytes": len(raw), "raw_sha256": hashlib.sha256(raw).hexdigest(), "parse_seconds": elapsed, "peak_working_set_bytes": counters.PeakWorkingSetSize, "peak_pagefile_bytes": counters.PeakPagefileUsage, **status}))


if len(sys.argv) > 1:
    one(sys.argv[1])
else:
    observations = []
    for case in ["minimal_10000", "dense_10000", "two_field_10000", "exact_200000_nodes", "over_200000_nodes"]:
        started_at = datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds")
        argv = [sys.executable, str(Path(__file__).resolve()), case]
        process = subprocess.run(argv, capture_output=True, text=True, check=False)
        log = RUN / ("resource-" + case + ".log")
        log.write_text(process.stdout + process.stderr, encoding="utf-8", newline="\n")
        assert process.returncode == 0, process.stderr
        observations.append({"argv": argv, "cwd": str(Path.cwd()), "started_at": started_at, "finished_at": datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds"), "exit_code": process.returncode, "log": log.name, **json.loads(process.stdout)})
    (RUN / "resource_observations.json").write_text(json.dumps(observations, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(observations, ensure_ascii=False, indent=2))
