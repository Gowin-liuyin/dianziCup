"""Verify only the authorized dependency checkpoint and its installed metadata."""

import hashlib
import importlib.metadata
import json
import subprocess
import tomllib
from datetime import datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
ORIGINAL = "f6acedcd2b004671c317f55dd058f46e5e517de9"
DEPENDENCY = "48b56033cf5daf3ce8cfaa710c0acbda7cc2356e"
DEPENDENCY_FILES = ["backend/pyproject.toml", "backend/uv.lock", "docs/decisions/CR-R11_R07_parser_dependencies.md"]


def blob(commit, path):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=ROOT)


before = tomllib.loads(blob(ORIGINAL, "backend/uv.lock").decode())
after_bytes = blob(DEPENDENCY, "backend/uv.lock")
after = tomllib.loads(after_bytes.decode())
before_versions = {package["name"]: package["version"] for package in before["package"]}
after_versions = {package["name"]: package["version"] for package in after["package"]}
changed = {name: [version, after_versions.get(name)] for name, version in before_versions.items() if after_versions.get(name) != version}
assert not changed, changed
added = {name: version for name, version in after_versions.items() if name not in before_versions}
assert added == {"packageurl-python": "0.17.6", "types-pyyaml": "6.0.12.20260906"}
files = []
for path in DEPENDENCY_FILES:
    current = subprocess.check_output(["git", "show", f"HEAD:{path}"], cwd=ROOT)
    frozen = blob(DEPENDENCY, path)
    assert current == frozen, path
    files.append({"path": path, "git_lf_sha256": hashlib.sha256(current).hexdigest(), "bytes": len(current)})
metadata = []
for name in ["packageurl-python", "pyyaml", "types-pyyaml"]:
    distribution = importlib.metadata.distribution(name)
    metadata.append({"name": name, "version": distribution.version, "license": distribution.metadata.get("License"), "license_expression": distribution.metadata.get("License-Expression"), "requires_python": distribution.metadata.get("Requires-Python"), "metadata_sha256": hashlib.sha256(distribution.read_text("METADATA").encode()).hexdigest()})
output = {
    "verified_at": datetime.now(timezone(timedelta(hours=8), "Asia/Shanghai")).isoformat(timespec="seconds"),
    "author_material_commit": ORIGINAL,
    "root_dependency_commit": DEPENDENCY,
    "combined_review_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "lock_original_packages": len(before_versions),
    "lock_combined_packages": len(after_versions),
    "changed_old_versions": changed,
    "added_packages": added,
    "files": files,
    "installed_metadata": metadata,
    "lock_git_sha256": hashlib.sha256(after_bytes).hexdigest(),
    "lock_working_sha256": hashlib.sha256((ROOT / "backend/uv.lock").read_bytes()).hexdigest(),
    "review_commit": None,
}
(RUN / "dependency_verification.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(output, ensure_ascii=False, indent=2))
