"""Independent, synthetic boundary and provenance checks for the frozen adapter."""

import copy
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest
from jsonschema import FormatChecker
from jsonschema.validators import validator_for
from packageurl import PackageURL
from referencing import Registry
from referencing.exceptions import NoSuchResource

from ai_intel.assets.sbom_parser import SbomValidationError, parse_sbom
from ai_intel.domain.access import AccessScope, CrossTenantAccessError, PermissionDeniedError, Role

RUN = Path(__file__).resolve().parent
ASSET = "fa0d8b75-5c2d-432d-a833-c6bfcf2f8583"
NOW = datetime(2026, 10, 16, 5, tzinfo=UTC)
SCOPE = AccessScope.for_authenticated_user("independent-review", "review-tenant", Role.ANALYST)


def cdx(version="1.7", components=None, **opaque):
    return {
        "bomFormat": "CycloneDX",
        "specVersion": version,
        "version": 1,
        "components": components if components is not None else [{"type": "library", "name": "a", "version": "1", "purl": "pkg:pypi/a@1", "bom-ref": "a"}],
        **opaque,
    }


def spdx():
    return {
        "spdxVersion": "SPDX-2.3",
        "SPDXID": "SPDXRef-DOCUMENT",
        "dataLicense": "CC0-1.0",
        "name": "Independent synthetic review",
        "documentNamespace": "https://review.example.invalid/document",
        "creationInfo": {"created": "2026-10-16T00:00:00Z", "creators": ["Tool: independent synthetic review"]},
        "packages": [{"SPDXID": "SPDXRef-a", "name": "a", "versionInfo": "1", "downloadLocation": "NOASSERTION", "filesAnalyzed": False}],
    }


def encode(document):
    return json.dumps(document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def parse(document, sbom_format="cyclonedx_json", **changes):
    arguments = dict(sbom_format=sbom_format, scope=SCOPE, authorized_asset_tenant_id="review-tenant", asset_id=ASSET, snapshot_number=1, source_version="independent-synthetic", observed_at=NOW, recorded_at=NOW)
    arguments.update(changes)
    return parse_sbom(document if isinstance(document, bytes) else encode(document), **arguments)


def deny_retrieval(uri):
    raise NoSuchResource(ref=uri)


def official(document, name):
    schema = json.loads((RUN / "frozen_raw" / (name + ".schema.json")).read_bytes())
    validator = validator_for(schema)
    validator.check_schema(schema)
    validator(schema, registry=Registry(retrieve=deny_retrieval), format_checker=FormatChecker()).validate(document)
    return validator.__name__


@pytest.mark.parametrize("version", ["1.5", "1.6", "1.7"])
def test_official_supported_version_and_hashes(version):
    document = cdx(version)
    assert official(document, "cyclonedx-" + version) == "Draft7Validator"
    result = parse(document)
    assert result.spec_version == version
    assert result.raw_sha256 == hashlib.sha256(encode(document)).hexdigest()
    assert result.manifest.snapshot.components[0].version == "1"


def test_spdx_with_its_actual_2019_09_dialect():
    document = spdx()
    assert official(document, "spdx-2.3.1") == "Draft201909Validator"
    result = parse(document, "spdx_json")
    assert result.spec_version == "SPDX-2.3"
    assert result.manifest.snapshot.components[0].ecosystem == "unknown"


@pytest.mark.parametrize("raw,code", [
    (b'{"opaque":{"a":1,"\\u0061":2}}', "duplicate_json_key"),
    (b'{"opaque":{"x":NaN}}', "non_finite_json_number"),
    (b'{"opaque":{"x":-Infinity}}', "non_finite_json_number"),
    (b'{"opaque":{"x":1e9999}}', "non_finite_json_number"),
    (b'{"\\udfff":"opaque"}', "invalid_json_unicode"),
    (b'{"opaque":["\\ud800"]}', "invalid_json_unicode"),
    (b'{"opaque":{"x":"\\u0000"}}', "invalid_json_unicode"),
    (b'{"opaque":{"$dynamicRef":"https://review.invalid/schema"}}', "unsupported_json_reference"),
])
def test_nested_malformed_inputs_have_typed_errors(raw, code):
    with pytest.raises(SbomValidationError) as error:
        parse(raw)
    assert error.value.code == code


def test_valid_surrogate_pair_remains_original_bytes():
    raw = encode(cdx(opaque="unicode")).replace(b'"unicode"', b'"\\ud83d\\ude00"')
    result = parse(raw)
    assert result.manifest.source_bytes == raw
    assert result.raw_sha256 == hashlib.sha256(raw).hexdigest()


def test_exact_raw_byte_boundary():
    raw = encode(cdx())
    exact = raw + b" " * (1048576 - len(raw))
    assert parse(exact).manifest.source_bytes == exact
    with pytest.raises(SbomValidationError) as error:
        parse(exact + b" ")
    assert error.value.code == "sbom_size_or_type_limit"


@pytest.mark.parametrize("leaf_depth", [16, 17])
def test_exact_json_depth_boundary(leaf_depth):
    opaque = "leaf"
    for _ in range(leaf_depth - 1):
        opaque = [opaque]
    document = cdx(opaque=opaque)
    if leaf_depth == 16:
        assert parse(document).manifest.source_bytes == encode(document)
    else:
        with pytest.raises(SbomValidationError) as error:
            parse(document)
        assert error.value.code == "json_depth_limit"


@pytest.mark.parametrize("count", [199989, 199990])
def test_exact_raw_node_boundary(count):
    document = cdx(components=[], opaque=[0] * count)
    assert len(encode(document)) < 1048576
    if count == 199989:
        assert parse(document).manifest.snapshot.components == ()
    else:
        with pytest.raises(SbomValidationError) as error:
            parse(document)
        assert error.value.code == "json_node_limit"


@pytest.mark.parametrize("purl", ["pkg:pypi/a@1?arch=x86", "pkg:npm/a@1#src", "pkg:pypi/a@1?repository_url=https%3A%2F%2Fprivate.invalid"])
def test_legal_qualifiers_and_subpaths_are_explicitly_unsupported(purl):
    assert PackageURL.from_string(purl).to_string()
    document = cdx()
    document["components"][0]["purl"] = purl
    official(document, "cyclonedx-1.7")
    with pytest.raises(SbomValidationError) as error:
        parse(document)
    assert error.value.code == "unsupported_purl_features"
    assert error.value.locator == "/components/0/purl"


@pytest.mark.parametrize("purl,name", [("pkg:npm/%40scope/lib@1.0.0", "@scope/lib"), ("pkg:pypi/Foo_Bar@1.0", "foo-bar")])
def test_mature_purl_decodes_namespace_and_normalizes_name(purl, name):
    document = cdx(components=[{"type": "library", "name": "Source label", "purl": purl}])
    result = parse(document)
    component = result.manifest.snapshot.components[0]
    assert component.package_name == name
    assert component.version is None
    assert component.display_name == "Source label"
    assert component.purl == purl


def test_unicode_identity_is_typed_unrepresentable_but_unicode_label_is_preserved():
    document = cdx(components=[{"type": "library", "name": "中文 label", "purl": "pkg:generic/%E7%BB%84%E4%BB%B6"}])
    with pytest.raises(SbomValidationError) as error:
        parse(document)
    assert error.value.code == "unsupported_package_name"
    document["components"][0]["purl"] = "pkg:generic/component"
    assert parse(document).manifest.snapshot.components[0].display_name == "中文 label"


@pytest.mark.parametrize("change", ["edge", "hash", "license", "comment", "opaque"])
def test_same_projection_changes_full_sidecar_and_combined_hash(change):
    original_document = cdx(components=[{"type": "library", "name": "a", "bom-ref": "a"}, {"type": "library", "name": "b", "bom-ref": "b"}])
    changed_document = copy.deepcopy(original_document)
    if change == "edge":
        changed_document["dependencies"] = [{"ref": "a", "dependsOn": ["b"]}]
    elif change == "hash":
        changed_document["components"][0]["hashes"] = [{"alg": "SHA-256", "content": "b" * 64}]
    elif change == "license":
        changed_document["components"][0]["licenses"] = [{"license": {"id": "MIT"}}]
    elif change == "comment":
        changed_document["components"][0]["description"] = "Changed source claim."
    else:
        changed_document["properties"] = [{"name": "private:opaque", "value": "changed"}]
    original, changed = parse(original_document), parse(changed_document)
    assert original.manifest.snapshot.snapshot_sha256 == changed.manifest.snapshot.snapshot_sha256
    assert original.manifest.snapshot.snapshot_id == changed.manifest.snapshot.snapshot_id
    assert original.sidecar_sha256 != changed.sidecar_sha256
    assert original.combined_semantic_sha256 != changed.combined_semantic_sha256
    assert changed.manifest.snapshot.components[0].image_digest is None


def test_object_key_order_whitespace_preserves_sidecar_and_combined():
    document = cdx()
    reordered = dict(reversed(list(document.items())))
    first, second = parse(encode(document)), parse(json.dumps(reordered, indent=2).encode())
    assert first.raw_sha256 != second.raw_sha256
    assert first.sidecar_sha256 == second.sidecar_sha256
    assert first.combined_semantic_sha256 == second.combined_semantic_sha256


@pytest.mark.parametrize("kind", ["scope_optional", "scope_excluded", "external", "range"])
def test_source_non_installed_or_unresolved_state_is_not_projected_as_installed(kind):
    document = cdx()
    item = document["components"][0]
    if kind.startswith("scope_"):
        item["scope"] = kind.removeprefix("scope_")
    elif kind == "external":
        item["isExternal"] = True
    else:
        item.pop("version")
        item["versionRange"] = "vers:pypi/>=1"
    with pytest.raises(SbomValidationError):
        parse(document)


def test_source_complete_and_config_comments_do_not_assert_facts():
    result = parse(cdx(compositions=[{"aggregate": "complete", "assemblies": ["a"]}], properties=[{"name": "unsafe_config", "value": "enabled"}]))
    snapshot = result.manifest.snapshot
    assert snapshot.inventory_completeness == "unknown" and snapshot.declared_scope == ()
    assert snapshot.configuration == ()
    assert snapshot.tool_permissions is None and snapshot.input_channels is None and snapshot.network_exposure is None


@pytest.mark.parametrize("changes,exception", [
    ({"scope": None}, PermissionDeniedError),
    ({"scope": AccessScope.for_authenticated_user("viewer", "review-tenant", Role.VIEWER)}, PermissionDeniedError),
    ({"authorized_asset_tenant_id": "other-tenant"}, CrossTenantAccessError),
])
def test_read_authorization_precedes_malformed_input(changes, exception):
    with pytest.raises(exception):
        parse(b"invalid", **changes)


def test_analyst_read_scope_parses_candidate_without_write_permission():
    result = parse(cdx())
    assert "write:asset" not in SCOPE.permissions
    assert result.manifest.snapshot.tenant_id == "review-tenant"


@pytest.mark.parametrize("sbom_format,document,field", [("cyclonedx_json", cdx(), "version"), ("spdx_json", spdx(), "versionInfo")])
def test_direct_version_absence_remains_unknown(sbom_format, document, field):
    document = copy.deepcopy(document)
    package = document["components" if sbom_format == "cyclonedx_json" else "packages"][0]
    package.pop(field)
    result = parse(document, sbom_format)
    assert result.manifest.snapshot.components[0].version is None


@pytest.mark.parametrize("sbom_format", ["spdx_json", "cyclonedx_json"])
def test_frozen_dense_input_gap_is_typed_and_not_truncated(sbom_format):
    if sbom_format == "cyclonedx_json":
        document = json.loads((RUN / "frozen_raw/synthetic-dense-10000.json").read_bytes())
        assert len(document["components"]) == 10000
    else:
        document = spdx()
        document["packages"] = [{"name": f"p{i}", "versionInfo": "1", "SPDXID": f"SPDXRef-{i}", "downloadLocation": "NOASSERTION"} for i in range(10000)]
    assert len(encode(document)) < 1048576
    with pytest.raises(SbomValidationError) as error:
        parse(document, sbom_format)
    assert error.value.code == "projection_node_limit"
