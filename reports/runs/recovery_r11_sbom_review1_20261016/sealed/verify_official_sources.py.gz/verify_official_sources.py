"""Cross-check frozen schemas against fixed official sources, without remote refs."""

import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

RUN = Path(__file__).resolve().parent
TIMEZONE = timezone(timedelta(hours=8), "Asia/Shanghai")
TARGET = RUN / "official_independent"
TARGET.mkdir(exist_ok=True)
SOURCES = [
    ("cyclonedx-1.5.schema.json", "https://raw.githubusercontent.com/CycloneDX/specification/1.5/schema/bom-1.5.schema.json"),
    ("cyclonedx-1.6.schema.json", "https://raw.githubusercontent.com/CycloneDX/specification/1.6/schema/bom-1.6.schema.json"),
    ("cyclonedx-1.7.schema.json", "https://raw.githubusercontent.com/CycloneDX/specification/1.7/schema/bom-1.7.schema.json"),
    ("spdx-2.3.1.schema.json", "https://raw.githubusercontent.com/spdx/spdx-spec/v2.3.1/schemas/spdx-schema.json"),
    ("packageurl-0.17.6.pypi.json", "https://pypi.org/pypi/packageurl-python/0.17.6/json"),
]


def fetch(source):
    name, url = source
    started_at = datetime.now(TIMEZONE).isoformat(timespec="seconds")
    argv = ["wsl", "--", "curl", "--fail", "--silent", "--show-error", "--location", "--max-time", "30", "--retry", "1", url]
    process = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    (TARGET / (name + ".stderr.log")).write_bytes(process.stderr)
    assert process.returncode == 0, process.stderr.decode(errors="replace")
    (TARGET / name).write_bytes(process.stdout)
    record = {"name": name, "url": url, "argv": argv, "cwd": str(Path.cwd()), "started_at": started_at, "finished_at": datetime.now(TIMEZONE).isoformat(timespec="seconds"), "exit_code": process.returncode, "bytes": len(process.stdout), "sha256": hashlib.sha256(process.stdout).hexdigest()}
    if name.endswith("schema.json"):
        record["equals_frozen_official_raw_bytes"] = process.stdout == (RUN / "frozen_raw" / name).read_bytes()
        assert record["equals_frozen_official_raw_bytes"], name
    else:
        release = json.loads(process.stdout)
        record["license"] = release["info"]["license"]
        hashes = {item["filename"]: item["digests"]["sha256"] for item in release["urls"]}
        record["wheel_sha256"] = hashes["packageurl_python-0.17.6-py3-none-any.whl"]
        assert record["wheel_sha256"] == "31a85c2717bc41dd818f3c62908685ff9eebcb68588213745b14a6ee9e7df7c9"
    return record


with ThreadPoolExecutor(max_workers=4) as executor:
    records = list(executor.map(fetch, SOURCES))
(RUN / "official_source_verification.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(records, ensure_ascii=False, indent=2))
