"""固定研究材料/合成原bytes/源码调用链收据；无PG/生产IO或秘密读取。"""

import gzip
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
CBM = "/tmp/dianzi-cbm-audit-20261014/portable/codebase-memory-mcp"
WSL = ["wsl", "-d", "Ubuntu-22.04", "-u", "root", "--exec"]


def run_command(name, arguments, receipts):
    started = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
    tick = time.monotonic()
    completed = subprocess.run(
        arguments, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )
    (RUN / (name + ".log")).write_bytes(completed.stdout)
    receipts.append(
        {
            "name": name,
            "argv": arguments,
            "cwd": str(ROOT),
            "started_at": started,
            "finished_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds"),
            "elapsed_seconds": round(time.monotonic() - tick, 6),
            "exit_code": completed.returncode,
            "log": name + ".log",
        }
    )
    (RUN / "evidence_commands.json").write_text(
        json.dumps(receipts, indent=2), encoding="utf-8", newline="\n"
    )
    print(json.dumps({"name": name, "exit_code": completed.returncode}), flush=True)
    return completed


def main():
    sys.path.insert(0, str(ROOT / "backend"))
    from tests.unit.test_r11_sbom_parser import cdx_document, parse, spdx_document

    from ai_intel.assets.sbom_parser import SbomValidationError

    receipts = []
    for tool in ("index_repository", "get_graph_schema", "get_architecture", "trace_path"):
        assert (
            run_command(
                "cbm_final2_help_" + tool, [*WSL, CBM, "cli", tool, "--help"], receipts
            ).returncode
            == 0
        )
    for suffix, directory in (("src", "backend/src"), ("assets", "backend/src/ai_intel/assets")):
        prefix = [
            *WSL,
            "env",
            "CBM_CACHE_DIR=/tmp/dianzi-r11-sbom-cbm-final",
            "CBM_ALLOWED_ROOT=/mnt/d/wt/r11-sbom-adapters/" + directory,
            CBM,
            "cli",
        ]
        project = "r11-sbom-" + suffix + "-final"
        for name, arguments in (
            (
                "index",
                [
                    "index_repository",
                    "--repo-path",
                    "/mnt/d/wt/r11-sbom-adapters/" + directory,
                    "--name",
                    project,
                    "--mode",
                    "full",
                    "--persistence",
                    "false",
                ],
            ),
            ("schema", ["get_graph_schema", "--project", project]),
            ("architecture", ["get_architecture", "--project", project, "--aspects", "all"]),
            (
                "parser_trace",
                [
                    "trace_path",
                    "--project",
                    project,
                    "--function-name",
                    "parse_manifest",
                    "--direction",
                    "inbound",
                    "--depth",
                    "2",
                ],
            ),
            (
                "adapter_trace",
                [
                    "trace_path",
                    "--project",
                    project,
                    "--function-name",
                    "parse_sbom",
                    "--direction",
                    "both",
                    "--depth",
                    "2",
                ],
            ),
        ):
            assert (
                run_command(
                    "cbm_final2_" + suffix + "_" + name, prefix + arguments, receipts
                ).returncode
                == 0
            )
    assert (
        run_command(
            "all_callers_final",
            ["rg", "-n", "parse_sbom|sbom_parser|parse_manifest", "backend/src", "backend/tests"],
            receipts,
        ).returncode
        == 0
    )
    (RUN / "evidence_commands.json").write_text(
        json.dumps(receipts, indent=2), encoding="utf-8", newline="\n"
    )

    fixtures = {
        "cdx-1.5": (cdx_document("1.5"), "cyclonedx_json"),
        "cdx-1.6": (cdx_document("1.6"), "cyclonedx_json"),
        "cdx-1.7": (cdx_document("1.7"), "cyclonedx_json"),
        "spdx-2.3": (spdx_document(), "spdx_json"),
    }
    fixtures["dense-10000"] = (
        cdx_document(
            components=[
                {
                    "type": "library",
                    "name": "p" + str(index),
                    "purl": "pkg:pypi/p" + str(index),
                    "version": "1",
                }
                for index in range(10000)
            ]
        ),
        "cyclonedx_json",
    )
    fixtures["minimal-10000"] = (
        cdx_document(
            components=[{"type": "library", "name": "p" + str(index)} for index in range(10000)]
        ),
        "cyclonedx_json",
    )
    records = []
    for name, (document, sbom_format) in fixtures.items():
        raw = json.dumps(document, ensure_ascii=False).encode()
        (RUN / ("synthetic-" + name + ".json.gz")).write_bytes(gzip.compress(raw, mtime=0))
        record = {
            "fixture_mode": "explicit_synthetic_offline",
            "name": name,
            "format": sbom_format,
            "raw_bytes": len(raw),
            "raw_sha256": hashlib.sha256(raw).hexdigest(),
            "artifact": "synthetic-" + name + ".json.gz",
        }
        try:
            result = parse(raw, sbom_format)
        except SbomValidationError as error:
            record.update(
                status="typed_rejected", error_code=error.code, source_locator=error.locator
            )
        else:
            record.update(
                status="candidate",
                components=len(result.manifest.snapshot.components),
                projection_hash=result.manifest.snapshot.snapshot_sha256,
                sidecar_hash=result.sidecar_sha256,
                combined_hash=result.combined_semantic_sha256,
                inventory_completeness=result.manifest.snapshot.inventory_completeness,
            )
        records.append(record)
    assert records[-2]["error_code"] == "projection_node_limit"
    assert records[-1]["components"] == 10000
    (RUN / "synthetic_input_receipt.json").write_text(
        json.dumps(records, indent=2), encoding="utf-8", newline="\n"
    )

    metadata = json.loads(gzip.decompress((RUN / "packageurl-pypi-0.17.6.json.gz").read_bytes()))
    wheel = next(item for item in metadata["urls"] if item["packagetype"] == "bdist_wheel")
    assert wheel["url"].startswith("https://files.pythonhosted.org/")
    started = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
    result = subprocess.run(
        [
            *WSL,
            "curl",
            "--fail",
            "--silent",
            "--show-error",
            "--max-time",
            "20",
            "--proto",
            "=https",
            wheel["url"],
        ],
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0
    digest = hashlib.sha256(result.stdout).hexdigest()
    assert digest == wheel["digests"]["sha256"]
    (RUN / (wheel["filename"] + ".gz")).write_bytes(gzip.compress(result.stdout, mtime=0))
    (RUN / "packageurl_wheel_receipt.json").write_text(
        json.dumps(
            {
                "version": "0.17.6",
                "license": metadata["info"]["license"],
                "url": wheel["url"],
                "raw_bytes": len(result.stdout),
                "sha256": digest,
                "expected_sha256": wheel["digests"]["sha256"],
                "exit_code": result.returncode,
                "started_at": started,
                "finished_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(
                    timespec="seconds"
                ),
                "artifact": wheel["filename"] + ".gz",
            },
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps({"synthetic_fixtures": len(records), "wheel_sha256_verified": digest}),
        flush=True,
    )


if __name__ == "__main__":
    main()
